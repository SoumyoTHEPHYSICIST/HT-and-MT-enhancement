import numpy as np
from sof_heatmass import nu_sh_baseline, enhancement_factor

def test_baseline_monotone():
    x = np.array([0.0, 1.0, 10.0])
    y = np.array([nu_sh_baseline(p) for p in x])
    assert y[0] > 0 and np.all(np.diff(y) >= -1e-9)

def test_enhancement_zero_De():
    Pe = np.array([0.1, 1.0, 10.0])
    Nu, enh = enhancement_factor(Pe, De=0.0, epsilon=-0.5)
    assert np.allclose(enh, 0.0)
