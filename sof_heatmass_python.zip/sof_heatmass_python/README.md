# SOF Heat/Mass Transfer (Python scaffold)

A **Spyder-friendly** scaffold to study **enhancement of heat/mass transfer in a Second-Order Fluid (SOF)** for **weak viscoelasticity** (small De). Plug your A(Pe), B(Pe) and baseline from Ganesh & Koch (2006) to reproduce exact figures.

## Quick start
- Open this folder in Spyder.
- Run `examples/run_ganesh2006_demo.py` to generate a placeholder plot.

## Where to edit
- `sof_heatmass/ganesh2006.py` → replace `default_A_fun`, `default_B_fun`, and `nu_sh_baseline` with the exact expressions from your derivation.

## Nondimensional groups
- `Pe = U a / κ`
- `De = (ψ₁/η) U/a` or `De = (ψ₁/η) G`
- `ε = ψ₂/ψ₁`

## Next steps
- Paste your Mathematica expressions for A(Pe), B(Pe).
- If you derived a reciprocal-theorem integral, add it as a function and call it from `enhancement_factor`.
