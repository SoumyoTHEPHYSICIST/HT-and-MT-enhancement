import numpy as np
import matplotlib.pyplot as plt
from typing import Sequence, Callable
from .ganesh2006 import enhancement_factor, nu_sh_baseline, default_A_fun, default_B_fun

def plot_enhancement_grid(Pe: np.ndarray,
                          De_values: Sequence[float],
                          eps_values: Sequence[float],
                          A_fun: Callable = default_A_fun,
                          B_fun: Callable = default_B_fun,
                          baseline_fun: Callable = nu_sh_baseline,
                          quantity: str = "Nu/Sh"):
    """
    Create small-multiples plot: curves for multiple ε at each De.
    """
    Pe = np.asarray(Pe, dtype=float)
    De_values = list(De_values)
    eps_values = list(eps_values)

    nrows = len(De_values)
    fig, axes = plt.subplots(nrows=nrows, ncols=1, figsize=(6, 3*nrows), sharex=True)
    if nrows == 1:
        axes = [axes]

    for ax, De in zip(axes, De_values):
        for eps in eps_values:
            Nu, _ = enhancement_factor(Pe, De=De, epsilon=eps,
                                       A_fun=A_fun, B_fun=B_fun, baseline_fun=baseline_fun)
            ax.plot(Pe, Nu, label=f"ε={eps:+.2f}")
        ax.set_title(f"{quantity} vs Pe at De={De:.3f}")
        ax.set_ylabel(quantity)
        ax.grid(True, ls=":")
        ax.legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel("Péclet number, Pe")
    fig.tight_layout()
    return fig, axes
