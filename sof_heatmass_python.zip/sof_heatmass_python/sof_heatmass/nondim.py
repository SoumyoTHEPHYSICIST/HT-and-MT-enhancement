from typing import Dict

def groups(eta: float, psi1: float, a: float, U: float, kappa: float, G: float = 0.0) -> Dict[str, float]:
    """
    Compute non-dimensional groups used in weakly viscoelastic SOF transport:
    - Pe: Péclet number based on U and a.
    - De_U: Deborah/Weissenberg based on U/a: De_U = (ψ₁/η) * (U/a).
    - De_G: Deborah/Weissenberg based on shear-rate G: De_G = (ψ₁/η) * G.
    """
    Pe = U * a / kappa if kappa > 0 else 0.0
    De_U = (psi1 / eta) * (U / a) if (eta > 0 and a > 0) else 0.0
    De_G = (psi1 / eta) * G if (eta > 0 and G > 0) else 0.0
    return {"Pe": Pe, "De_U": De_U, "De_G": De_G}
