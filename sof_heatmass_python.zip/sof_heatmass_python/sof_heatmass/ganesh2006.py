import numpy as np
from typing import Callable, Literal, Tuple

CaseType = Literal["uniform-flow-sphere", "linear-shear-sphere", "general-linear-flow"]

def nu_sh_baseline(Pe: float, kind: Literal["heat","mass"]="mass") -> float:
    """
    Baseline (Newtonian, De→0) Nusselt/Sherwood number for a sphere.
    Default placeholder is Nu/Sh ≈ 2 at Pe→0 with mild Pe^{1/3} growth.
    Replace with your exact expression.
    """
    Pe = float(Pe)
    c = 0.06
    return 2.0 * (1.0 + c * (Pe**(1.0/3.0)))

def default_A_fun(Pe: np.ndarray) -> np.ndarray:
    return 0.12 * (1.0 - np.exp(-0.5 * np.sqrt(Pe + 1e-12)))

def default_B_fun(Pe: np.ndarray) -> np.ndarray:
    return -0.08 * (1.0 - np.exp(-0.35 * np.sqrt(Pe + 1e-12)))

def enhancement_factor(Pe: np.ndarray,
                       De: float,
                       epsilon: float,
                       A_fun: Callable[[np.ndarray], np.ndarray]=default_A_fun,
                       B_fun: Callable[[np.ndarray], np.ndarray]=default_B_fun,
                       baseline_fun: Callable[[float], float]=lambda Pe: nu_sh_baseline(Pe, "mass")
                       ) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute Nu/Sh and relative enhancement vs Newtonian baseline for arrays of Pe.
    Returns (Nu, enhancement) where enhancement = (Nu - Nu0)/Nu0.
    """
    Pe = np.atleast_1d(Pe).astype(float)
    Nu0 = np.array([baseline_fun(p) for p in Pe])
    corr = 1.0 + De * (A_fun(Pe) + epsilon * B_fun(Pe))
    Nu = Nu0 * corr
    enh = (Nu - Nu0) / Nu0
    return Nu, enh
