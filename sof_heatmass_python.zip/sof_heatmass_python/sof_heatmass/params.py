from dataclasses import dataclass

@dataclass
class SOFParams:
    eta: float            # Total viscosity (Pa·s)
    psi1: float           # First normal-stress coefficient (Pa·s^2)
    psi2: float           # Second normal-stress coefficient (Pa·s^2)
    kappa: float          # Thermal or mass diffusivity (m^2/s) -> α (heat) or D (mass)
    a: float              # Sphere radius (m) or characteristic length
    U: float              # Characteristic velocity (m/s) (e.g., G*a or slip)
    G: float              # Shear rate (1/s), if relevant (set 0 if using U-based scaling)
    rho: float = 1000.0   # Density (kg/m^3), not used in creeping flow but kept for completeness

    @property
    def epsilon(self) -> float:
        """
        SOF material ratio ε = ψ₂/ψ₁. In many papers -1 ≤ ε ≤ 0.
        """
        if self.psi1 == 0:
            return 0.0
        return self.psi2 / self.psi1
