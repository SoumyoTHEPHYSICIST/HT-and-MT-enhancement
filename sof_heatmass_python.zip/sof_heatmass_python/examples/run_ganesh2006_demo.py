import numpy as np
from sof_heatmass import SOFParams, groups, plot_enhancement_grid

# Example parameters (placeholders). Replace with your real values.
p = SOFParams(
    eta=1.0,         # Pa·s
    psi1=0.05,       # Pa·s^2
    psi2=-0.03,      # Pa·s^2
    kappa=1.4e-7,    # m^2/s (thermal) or D for mass transfer
    a=5e-5,          # m
    U=5e-3,          # m/s
    G=100.0          # 1/s
)

# Choose De based on U/a (or use De_G if you prefer shear-rate scaling)
nd = groups(p.eta, p.psi1, p.a, p.U, p.kappa, p.G)
Pe = np.logspace(-2, 2, 200)
De = nd["De_U"]
eps_values = [ -0.9, -0.7, -0.5, -0.3, -0.1 ]
De_values  = [ 0.02, 0.05, 0.10 ]

from sof_heatmass import plotting
fig, axes = plotting.plot_enhancement_grid(Pe, De_values, eps_values, quantity="Nu (placeholder)")
fig.savefig("nu_enhancement_placeholder.png", dpi=160)
print("Saved: nu_enhancement_placeholder.png")
